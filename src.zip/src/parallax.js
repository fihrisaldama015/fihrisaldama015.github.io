import { Parallax, Background } from 'react-parallax';

export const ParallaxC = () => (
        <Parallax
        bgImage="./images.jpg"
        renderLayer={percentage => (
            <div
                style={{
                    position: 'absolute',
                    background: `rgba(255, 125, 0, ${percentage * 100})`,
                    left: '50%',
                    top: '50%',
                    width: percentage * 500,
                    height: percentage * 500,
                }}
            />
        )}
    >   
        <Background className="custom-bg">
            <img src="http://www.fillmurray.com/500/320" alt="fill murray" />
        </Background>
        <p>... POEEEEEE</p>
    </Parallax>
);