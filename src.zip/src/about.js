import React from 'react';

export const About = () => {
    return (
        <div>
            <p>Name : User</p>
            <p>Email : User@gmail.com</p>
        </div>
    )
}