import React from 'react';
import styled from 'styled-components';

const BlueButton = styled.button`
    background:#282c34;
    border:2px solid #61dafb;
    border-radius:10px;
    padding: 10px;
    color:#61dafb;
    font-weight:600;
    margin-top:2vh;
    transition:0.2s;
    &:hover {
      background-color:#61dafb;
      color:#282c34;
      transition:0.2s;
    }
`;

export class Button extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      judul:"Poe Button",
      isi:""};
    this.clickHandler = this.clickHandler.bind(this);
    this.clickMagic = this.clickMagic.bind(this);
    this.hoverHandler = this.hoverHandler.bind(this);
    this.judul = this.judul.bind(this);
  };clickHandler() {
    this.setState({judul:"Poe Button",isi:""});
  };clickMagic() {
    this.setState({judul:"NGERONGG AWOKOWAKO"});
  };hoverHandler() {
    this.setState({isi:"POE"});
  };judul() {
    this.setState({judul:"LULUL GAOLEE"});
  }

  render() {
    const Container = styled.div`
    background-color: #61dafb;
    color:#282c34;
    display: block;
    margin: 0 auto;
    padding: 10px 20px;
    border: 2px solid #61dafb;
    border-radius:10px;
    font-weight:600;
    transition: 0.2s;
    min-height:12vh;
    min-width:1vh;
    max-width:10vh;
    text-align:center;
    &:hover {
      ${state => this.state.isi === "" ? "border-radius:20px;" : "border-radius:10px;"}
      background-color: #282c34;
      color:#61dafb;
    }
  `;
    return (
      <div>
        <p onMouseOver={this.judul}>
        {this.state.judul}
        </p>
        <div>
          <Container>
            <p>{this.state.isi}</p>
          </Container>
          <BlueButton onClick={this.clickMagic} onMouseOver={this.hoverHandler}>
              Magic Button
          </BlueButton><br />
          <BlueButton onClick={this.clickHandler}>
              Remove
          </BlueButton>
        </div>
      </div>
    );
  }
}
