import logo from './logo.svg';
import logo2 from './Asset1.svg';
import './App.css';
import {React} from './index';
import {Button} from './button';
import {About} from './about';
import { ParallaxC } from './parallax';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

const ReactImg = () => {
  return(
    <img src={logo} className="App-logo" alt="logo" />
  )
}

function App() {
  return (
    <Router>
      <div>
        <nav className="App-nav">
          <div className="Main-logo">
          <img src={logo2} alt="App-logo"/>
          </div>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/button">Button</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/test">Parallax</Link>
            </li>
          </ul>
        </nav>
        <div className="App">
          <header className="App-header">
            <Switch>
              
              <Route path="/button">
                <ReactImg />
                <Button />
              </Route>
              <Route path="/about">
                <h1>About me</h1>
                <ReactImg />
                <About />
              </Route>
              <Route path="/test">
                <ParallaxC />
              </Route>
              <Route path="/">
                <ReactImg />
                <h1>Welcome to home!</h1>
              </Route>
            </Switch>
          </header>
        </div>
      </div>
    </Router>
  );
}

export default App;
